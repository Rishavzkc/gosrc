package Service

import (
	"github.com/gin-gonic/gin"
)

type CompanyService interface {
	GetCompany(c *gin.Context)
	CreateCompany(c *gin.Context)
	GetCompanyById(c *gin.Context)
	UpdateCompany(c *gin.Context)
	DeleteCompany(c *gin.Context)
}

/*type companyService struct {
	companies []Model.Company
}*/

/*func (com *Model.Company) GetCompany() {
com.Id= []Model.Company

} */
