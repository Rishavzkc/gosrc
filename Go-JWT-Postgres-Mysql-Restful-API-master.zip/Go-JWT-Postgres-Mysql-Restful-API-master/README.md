[![CircleCI](https://circleci.com/gh/victorsteven/Go-JWT-Postgres-Mysql-Restful-API.svg?style=svg)](https://circleci.com/gh/victorsteven/Go-JWT-Postgres-Mysql-Restful-API)

# Go-JWT-Postgres-Mysql-Restful-API
This is an application built with golang, jwt, gorm, postgresql, mysql.

You can follow the guide here:
https://levelup.gitconnected.com/crud-restful-api-with-go-gorm-jwt-postgres-mysql-and-testing-460a85ab7121

### Dockerizing the API
The dockerized API can be found here:
https://github.com/victorsteven/Dockerized-Golang-Postgres-Mysql-API
